#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
BUILD="${1:-build}"
"$BUILD/coddle-tests"
"$BUILD/coddle-policy-tests"
"$BUILD/coddle-assertion-tests"
"$BUILD/coddle-integration-tests"
"$BUILD/coddle-selftest"
# Render the real panel and measure it the way the menu bar popover sizes
# itself. The fixed-size Dock window cannot catch a collapsed scroll region.
tests/ui/build.sh "$BUILD/ui-review" build
UI="$BUILD/ui-review/CoddleReviewUI.app/Contents/MacOS/CoddleReviewUI"
# cacheDisplay cannot composite native glass layers. Use opaque layout captures
# for the six-language matrix and native screenshots for glass visual acceptance.
rm -f "$BUILD/ui-review/coddle-ui-evidence/render-report.json" \
  "$BUILD/ui-review/coddle-ui-evidence/render-failure.txt" \
  "$BUILD/ui-review/coddle-ui-evidence/e2e-report.json"
"$UI" --render --output "$BUILD/ui-review" --languages en,zh-Hans,zh-Hant,ja,ko,es \
  --themes liquidGlass,classic --reduce-transparency true
test -f "$BUILD/ui-review/coddle-ui-evidence/render-report.json"
# Fitting panels stay still; overflow keeps a fixed backdrop and reachable footer.
rm -f "$BUILD/ui-review/coddle-ui-evidence/scroll-viewport-report.json"
"$UI" --render --audit scroll-viewport --output "$BUILD/ui-review"
test -f "$BUILD/ui-review/coddle-ui-evidence/scroll-viewport-report.json"
test ! -f "$BUILD/ui-review/coddle-ui-evidence/render-failure.txt"
# Keep telemetry columns equal in every locale and state, with complete AX values.
rm -f "$BUILD/ui-review/coddle-ui-evidence/power-flow-report.json"
"$UI" --render --audit power-flow --output "$BUILD/ui-review" --reduce-transparency true
test -f "$BUILD/ui-review/coddle-ui-evidence/power-flow-report.json"
test ! -f "$BUILD/ui-review/coddle-ui-evidence/render-failure.txt"
# Interaction uses native glass; bitmap layout captures temporarily use Classic.
rm -f "$BUILD/ui-review/coddle-ui-evidence/child-options-report.json"
"$UI" --render --audit child-options --output "$BUILD/ui-review"
test -f "$BUILD/ui-review/coddle-ui-evidence/child-options-report.json"
test ! -f "$BUILD/ui-review/coddle-ui-evidence/render-failure.txt"
"$UI" --e2e --output "$BUILD/ui-review"
test -f "$BUILD/ui-review/coddle-ui-evidence/e2e-report.json"
# Cleanup evidence must await the same asynchronous OFF/restore operations.
rm -f "$BUILD/ui-review/coddle-ui-evidence/cleanup-report.json"
"$BUILD/ui-review/CoddleReviewUI.app/Contents/MacOS/CoddleReviewUI" \
  --render --audit cleanup --output "$BUILD/ui-review"
test -f "$BUILD/ui-review/coddle-ui-evidence/cleanup-report.json"
"$BUILD/ui-review/CoddleReviewUI.app/Contents/MacOS/CoddleReviewUI" \
  --render --audit quit-cleanup --output "$BUILD/ui-review"
python3 - "$BUILD/ui-review/coddle-ui-evidence/state.json" <<'PY'
import json, sys
state = json.load(open(sys.argv[1]))
assert state["cleaned"]
assert not state["systemAssertionActive"] and not state["displayAssertionActive"]
assert state["helperWrites"][-1] is False
PY
# The periodic app list must not resize the mounted panel as samples change.
rm -f "$BUILD/ui-review/coddle-ui-evidence/activity-refresh-report.json"
"$BUILD/ui-review/CoddleReviewUI.app/Contents/MacOS/CoddleReviewUI" \
  --render --audit activity --output "$BUILD/ui-review"
test -f "$BUILD/ui-review/coddle-ui-evidence/activity-refresh-report.json"
# Sample the in-flight frames too: a settled-height check misses transient banners.
rm -f "$BUILD/ui-review/coddle-ui-evidence/activity-motion-report.json" \
  "$BUILD/ui-review/coddle-ui-evidence/render-failure.txt"
"$BUILD/ui-review/CoddleReviewUI.app/Contents/MacOS/CoddleReviewUI" \
  --render --audit activity-motion --output "$BUILD/ui-review"
test -f "$BUILD/ui-review/coddle-ui-evidence/activity-motion-report.json"
test ! -f "$BUILD/ui-review/coddle-ui-evidence/render-failure.txt"
APP="$(dirname "$BUILD")/Coddle.app"
codesign --verify --deep --strict --all-architectures "$APP"
codesign --verify --strict --all-architectures "$APP/Contents/Resources/coddle-helper"
python3 tests/helper_socket_regression.py --output-dir "$BUILD/regression"
python3 tests/helper_install_regression.py --output-dir "$BUILD/regression"
python3 tests/powerui_bridge_regression.py --output-dir "$BUILD/regression"
bash tests/onboarding/build.sh "$BUILD/onboarding-review"
