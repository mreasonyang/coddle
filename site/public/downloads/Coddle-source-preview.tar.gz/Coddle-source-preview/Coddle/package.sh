#!/usr/bin/env bash
# Build a universal, ad-hoc signed delivery without installing it.
set -euo pipefail
cd "$(dirname "$0")"
DEST="${1:-../../../dist}"
mkdir -p "$DEST"
DEST="$(cd "$DEST" && pwd)"
for architecture in arm64 x86_64; do
  CODDLE_ARCH="$architecture" CODDLE_OUTPUT_DIR="$DEST/$architecture" ./build.sh
done
APP="$DEST/Coddle.app"
rm -rf "$APP"
cp -R "$DEST/arm64/Coddle.app" "$APP"
for component in Contents/MacOS/Coddle Contents/Resources/coddle-helper; do
  lipo -create "$DEST/arm64/Coddle.app/$component" "$DEST/x86_64/Coddle.app/$component" -output "$APP/$component"
done
codesign --force --sign - "$APP/Contents/Resources/coddle-helper"
codesign --verify --strict --all-architectures "$APP/Contents/Resources/coddle-helper"
codesign --force --deep --sign - "$APP"
codesign --verify --deep --strict --all-architectures "$APP"
/usr/bin/ditto -c -k --sequesterRsrc --keepParent "$APP" "$DEST/Coddle-universal.zip"
(
  cd "$DEST"
  shasum -a 256 Coddle-universal.zip > Coddle-universal.zip.sha256
)
printf 'Built %s (ad-hoc signed; not notarized)\n' "$DEST/Coddle-universal.zip"
