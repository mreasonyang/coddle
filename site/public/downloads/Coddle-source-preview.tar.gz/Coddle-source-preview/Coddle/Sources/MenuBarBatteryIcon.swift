import AppKit

/// Coddle's menu-bar mark: the same 18×18 vessel as `MenuBarIcon.svg`.
///
/// It stays one icon. Level stays in the percentage text, so this item does not
/// grow a second battery beside the system one. Charging adds a bolt inside the
/// hollow body — the same signal the system battery uses — without changing the
/// silhouette or the slot size.
enum MenuBarBatteryIcon {
    struct State: Hashable {
        var hasBattery: Bool
        var percent: Int?
        /// True only while the pack is on power and actually taking a charge.
        var showsBolt: Bool
    }

    /// `chargeOverridePresented` is already AC-gated. `isCharging` is ANDed with
    /// external power so a stale charging bit on battery cannot draw a bolt.
    static func state(
        present: Bool,
        installed: Bool,
        percent: Int?,
        externalConnected: Bool,
        isCharging: Bool,
        chargeOverridePresented: Bool
    ) -> State {
        let hasBattery = present && installed
        let clamped = percent.map { min(100, max(0, $0)) }
        let charging = hasBattery && externalConnected && (isCharging || chargeOverridePresented)
        return State(hasBattery: hasBattery, percent: hasBattery ? clamped : nil, showsBolt: charging)
    }

    static func image(for state: State) -> NSImage {
        cacheLock.lock()
        defer { cacheLock.unlock() }
        if let cached = cache[state] { return cached }
        let image = render(state)
        cache[state] = image
        return image
    }

    /// Original template slot. Charging does not grow it.
    static let canvas = NSSize(width: 18, height: 18)

    // MARK: - Drawing

    private static let cacheLock = NSLock()
    private static var cache: [State: NSImage] = [:]

    private static func render(_ state: State) -> NSImage {
        let image = NSImage(size: canvas)
        for scale in [1, 2, 3] as [CGFloat] {
            guard let rep = bitmap(scale: scale, draw: { draw(state) }) else { continue }
            image.addRepresentation(rep)
        }
        image.isTemplate = true
        return image
    }

    private static func draw(_ state: State) {
        NSColor.black.setFill()
        // Cap rects overlap. They stay on a nonzero path so the cross stays solid;
        // even-odd is only for the hollow body.
        cap().fill()
        body().fill()
        if state.showsBolt { bolt().fill() }
    }

    /// Vessel from `MenuBarIconTemplate.png`. That asset is the vertical mirror
    /// of `MenuBarIcon.svg`: the cross sits under the body. Match the asset,
    /// because that is the mark already in the menu bar.
    private static func cap() -> NSBezierPath {
        let path = NSBezierPath()
        path.append(NSBezierPath(rect: NSRect(x: 8, y: 13, width: 2, height: 4)))
        path.append(NSBezierPath(rect: NSRect(x: 6, y: 14, width: 6, height: 2)))
        return path
    }

    private static func body() -> NSBezierPath {
        let path = NSBezierPath(roundedRect: NSRect(x: 4, y: 1, width: 10, height: 11), xRadius: 1.15, yRadius: 1.15)
        path.append(NSBezierPath(rect: NSRect(x: 6, y: 3, width: 6, height: 7)))
        path.windingRule = .evenOdd
        return path
    }

    /// Lightning centered in the hollow body. It does not reach the outline.
    private static func bolt() -> NSBezierPath {
        let path = NSBezierPath()
        path.move(to: NSPoint(x: 9.7, y: 9.3))
        path.line(to: NSPoint(x: 7.3, y: 6.4))
        path.line(to: NSPoint(x: 8.55, y: 6.4))
        path.line(to: NSPoint(x: 7.7, y: 3.85))
        path.line(to: NSPoint(x: 10.6, y: 6.85))
        path.line(to: NSPoint(x: 9.25, y: 6.85))
        path.close()
        return path
    }

    private static func bitmap(scale: CGFloat, draw: () -> Void) -> NSBitmapImageRep? {
        let pixelsWide = Int((canvas.width * scale).rounded())
        let pixelsHigh = Int((canvas.height * scale).rounded())
        guard let rep = NSBitmapImageRep(
            bitmapDataPlanes: nil,
            pixelsWide: pixelsWide,
            pixelsHigh: pixelsHigh,
            bitsPerSample: 8,
            samplesPerPixel: 4,
            hasAlpha: true,
            isPlanar: false,
            colorSpaceName: .deviceRGB,
            bytesPerRow: pixelsWide * 4,
            bitsPerPixel: 32
        ), let context = NSGraphicsContext(bitmapImageRep: rep) else { return nil }
        rep.size = canvas
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = context
        context.imageInterpolation = .none
        context.cgContext.scaleBy(x: scale, y: scale)
        context.cgContext.clear(CGRect(origin: .zero, size: canvas))
        context.cgContext.setShouldAntialias(true)
        draw()
        context.flushGraphics()
        NSGraphicsContext.restoreGraphicsState()
        return rep
    }
}
