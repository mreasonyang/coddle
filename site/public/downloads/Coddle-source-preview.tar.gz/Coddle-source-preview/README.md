# Coddle 0.1.0 source

Source for the 2026-10-22 preview, revision 6b610dd4d0b133f8dd5775696a91831425722261.
This source includes the preserved working-tree inputs used for the app.
Licensed under MIT; the license is included.

## Build on macOS

Install Apple command-line development tools or Xcode with a Swift compiler and
macOS SDK, plus Python 3. The deployment target is macOS 13.0.
UI tests need a graphical macOS session.

```sh
cd Coddle
./build.sh
./test.sh
```

The app is written to `Coddle/Coddle.app`. For both CPU architectures, run
`./package.sh /tmp/coddle-preview-build` from the same Coddle directory.
The included build scripts use ad-hoc signing, without Developer ID signing or
Apple notarization. Building and packaging do not install the optional helper;
installation requires an explicit in-app action and administrator authorization.

Feature availability is checked at runtime. Intel/macOS 13 runtime, physical
lid/display combinations, and full VoiceOver testing remain open. Automated
checks do not establish those device results.
